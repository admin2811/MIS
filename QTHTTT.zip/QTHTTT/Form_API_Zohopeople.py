import requests

# Địa chỉ URL API của Zoho Forms
url = "https://peopleplus.zoho.com/869819473/zp#settings/service/accountsetup/nonusers/nall"

# Headers, bao gồm tổ chức ID và token OAuth
headers = {
    "ZFORM-ORGID": "867896149",  # Thay bằng Organization ID của bạn
    "Authorization": "Zoho-oauthtoken 1000.b75503c176b21529ea7de386eb4ca65b.1003f6e0cf5dc7abc97a848af66c10de"  # Thay bằng token OAuth của bạn
}

# Tham số yêu cầu (nếu có)
params = {
    "CONFIG": '{"responseFormat":"json"}'
}

# Gửi yêu cầu GET tới Zoho Forms
response = requests.get(url, headers=headers, params=params)

# Kiểm tra trạng thái phản hồi
if response.status_code == 200:
    data = response.json()
    
    # Giả sử dữ liệu nằm trong trường 'data'
    if 'data' in data:
        # Lặp qua từng mục và xóa trường 'Referrer Name' (nếu cần)
        for item in data['data']:
            if 'Referrer Name' in item:
                del item['Referrer Name']
        
        print("Dữ liệu sau khi loại bỏ trường 'Referrer Name':")
        print(data['data'])
    else:
        print("Không có dữ liệu.")
else:
    print(f"Yêu cầu thất bại với mã lỗi: {response.status_code}")
    print(response.text)
