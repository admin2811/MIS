import pandas as pd
import requests
import json

try:
    # Bước 1: Đọc file CSV
    file_path = "D:/QTHTTT/Updated_Employee_View.csv"  # Đảm bảo đường dẫn chính xác
    data = pd.read_csv(file_path)

    # Bước 2: Chuyển đổi định dạng ngày tháng
    if 'final_confirmation_date' in data.columns:
        # Chuyển đổi ngày tháng từ định dạng '25-Oct-2024 16:31:47' sang '2024-10-25 16:31:47'
        data['final_confirmation_date'] = pd.to_datetime(
            data['final_confirmation_date'], 
            format='%d-%b-%Y %H:%M:%S', 
            errors='coerce'  # Chuyển đổi ngày tháng không hợp lệ thành NaT
        )

        # Kiểm tra xem có giá trị NaT nào không
        if data['final_confirmation_date'].isnull().any():
            print("Có lỗi trong định dạng 'final_confirmation_date'. Một số giá trị đã được chuyển thành NaT.")

        data['final_confirmation_date'] = data['final_confirmation_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

    # Xử lý các trường ngày tháng khác
    if 'Date of Joining' in data.columns:
        data['Date of Joining'] = pd.to_datetime(data['Date of Joining'], errors='coerce').dt.strftime('%Y-%m-%d')

        # Kiểm tra xem có giá trị NaT nào không
        if data['Date of Joining'].isnull().any():
            print("Có lỗi trong định dạng 'Date of Joining'. Một số giá trị đã được chuyển thành NaT.")

    if 'Date of Birth' in data.columns:
        data['Date of Birth'] = pd.to_datetime(data['Date of Birth'], errors='coerce').dt.strftime('%Y-%m-%d')

        # Kiểm tra xem có giá trị NaT nào không
        if data['Date of Birth'].isnull().any():
            print("Có lỗi trong định dạng 'Date of Birth'. Một số giá trị đã được chuyển thành NaT.")

    # Bước 3: Chuyển đổi dữ liệu thành JSON
    json_data = data.to_json(orient="records", force_ascii=False)
    json_data = json.loads(json_data)

    print("Dữ liệu JSON chuẩn bị gửi:")
    print(json.dumps(json_data, ensure_ascii=False, indent=2))  # In ra với định dạng đẹp hơn

    # Bước 4: Gửi JSON tới webhook
    webhook_url = "https://vannam.app.n8n.cloud/webhook-test/e55c7223-a293-4702-99df-79d3860d4a30"  # Thay thế bằng URL của webhook
    headers = {"Content-Type": "application/json"}

    # Thực hiện POST request
    response = requests.post(webhook_url, json=json_data, headers=headers)

    # Kiểm tra kết quả
    if response.status_code == 200:
        print("Dữ liệu đã được gửi thành công!")
    else:
        print(f"Lỗi khi gửi dữ liệu: {response.status_code} - {response.text}")

except FileNotFoundError:
    print("Không tìm thấy file CSV. Hãy kiểm tra lại đường dẫn.")
except pd.errors.EmptyDataError:
    print("File CSV trống. Vui lòng kiểm tra lại nội dung file.")
except pd.errors.ParserError:
    print("Có lỗi khi phân tích file CSV. Vui lòng kiểm tra định dạng của file.")
except requests.exceptions.RequestException as e:
    print(f"Lỗi kết nối khi gửi dữ liệu: {e}")
except Exception as e:
    print(f"Đã xảy ra lỗi: {e}")
