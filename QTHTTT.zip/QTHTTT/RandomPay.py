import pandas as pd
import random
import os

# Đường dẫn đến file CSV hiện tại
file_path = "D:/QTHTTT/Employee View.csv"  # Đảm bảo đường dẫn chính xác
# Đường dẫn đến file CSV mới
new_file_path = "D:/QTHTTT/Updated_Employee_View.csv"  # File mới sẽ được tạo

try:
    # Bước 1: Kiểm tra xem file có tồn tại không
    if os.path.exists(file_path):
        print("File CSV đã tồn tại, đang tiến hành đọc dữ liệu...")
        
        # Bước 2: Đọc file CSV
        data = pd.read_csv(file_path)
        print("Đã đọc dữ liệu từ file CSV.")
        
        # Bước 3: Thêm cột mới với dữ liệu ngẫu nhiên
        num_employees = len(data)  # Số lượng nhân viên hiện có

        # Tạo cột lương 1 giờ ngẫu nhiên từ 200,000 đến 1,500,000
        data['Hourly Rate'] = [random.choice(range(200000, 1500001, 100000)) for _ in range(num_employees)]  # Lương 1 giờ

        # Tính lương cơ bản
        days_per_week = 5
        weeks_per_month = 4
        total_days = days_per_week * weeks_per_month  # Tổng số ngày làm trong tháng
        data['Basic Salary'] = data['Hourly Rate'] * total_days  # Tính lương cơ bản

        # Thêm các cột khác với dữ liệu ngẫu nhiên
        data['Allowances'] = [random.choice(range(1000000, 3000001, 10000)) for _ in range(num_employees)]  # Phụ cấp
        data['Deductions'] = [random.choice(range(500000, 2000001, 10000)) for _ in range(num_employees)]  # Khấu trừ
        data['Bonus'] = [random.choice(range(0, 2000001, 100)) for _ in range(num_employees)]  # Thưởng

        # Bước 4: Lưu lại dữ liệu đã cập nhật vào file CSV mới
        data.to_csv(new_file_path, index=False, encoding='utf-8-sig')
        print(f"Đã thêm các cột dữ liệu mới và lưu vào file CSV mới: {new_file_path}")

        # Bước 5: Đọc lại file mới để xác minh dữ liệu đã được lưu
        updated_data = pd.read_csv(new_file_path)
        print("Dữ liệu đã cập nhật trong file mới:")
        print(updated_data.head())  # In ra 5 hàng đầu tiên của DataFrame
    else:
        print("File CSV không tồn tại. Vui lòng kiểm tra lại đường dẫn.")
except Exception as e:
    print(f"Đã xảy ra lỗi: {e}")
