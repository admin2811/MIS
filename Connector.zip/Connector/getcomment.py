import requests
import pandas as pd
import json

page_id = '433026843230142' # your page id, ex: '123456789'
post_id = '122116022414565575' # your post id, ex: '123456789'
access_token = 'EAAM5zQe6F5YBOyluQZCewN3RLT4xO3ZAmsmMyLU3IiiGDEZC7Sf2NMgcw0OKPC1QTBYu4xg1npPO9jNqIatEijYmD7UDSLSVvPQlr1vYUZAU8jVv9l2nuqxdmJUyUIyU0VwbaZARUnoQiLpCBDhWZCYKJ9Q7zwzdqR6kAgI582dbvV6RHv4Te5uQ3DYzAVxJvORpqyWsf2G1gQEANQ7DKb7dkA'
url = f'https://graph.facebook.com/v21.0/{page_id}_{post_id}/comments?access_token={access_token}'

response = requests.request("GET", url)

# save name, time, message in excel file
data = json.loads(response.text)
print(data)

# create object with only name, time, message
def get_comment(comment):
    return {
        'name': comment['from']['name'],
        'time': comment['created_time'],
        'message': comment['message']
    }

print(data)

excel_data = list(map(get_comment, data['data']))
df = pd.DataFrame(excel_data)
df.to_excel('comments.xlsx', index=False)