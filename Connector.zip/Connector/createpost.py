import requests

url = "https://63httt1nhom5mi.erpnext.com/api/resource/Social%20Post%20Create?fields=[\"message\"]"
headers = {
    "Authorization": "token 489782b30bc27fe:251123b658fbb85"
}
response = requests.get(url, headers=headers)
data = response.json()
print(data)