import requests

# workspace_id = 2966205000000004005
# view_id = 2966205000000004015

workspace_id = 2966205000000004005
view_id = 2966205000000041164


url_zoho = f"https://analyticsapi.zoho.com/restapi/v2/workspaces/{workspace_id}/views/{view_id}/data"
url_n8n = "https://mis5lam.app.n8n.cloud/webhook/ad88082a-6ab8-4349-a3ba-428a4e6c94ed"

headers_zoho = {
    "ZANALYTICS-ORGID": "869591002",  
    "Authorization": "Zoho-oauthtoken 1000.5d6f93468b98b9723a0824625ceb6d4a.a5729343f95143d1d710c752df7e542c"
}

params_zoho = {
    "CONFIG": '{"responseFormat":"json"}'
}

response = requests.get(url_zoho, headers=headers_zoho, params=params_zoho)

if response.status_code == 200:
    data = response.json()
    print("Dữ liệu nhận được:")
    print(data)
else:
    print(f"Yêu cầu thất bại với mã lỗi: {response.status_code}")
    print(response.text)

# Gửi dữ liệu dạng POST request đến webhook của n8n
response = requests.post(url_n8n, json=data)

# Kiểm tra phản hồi
if response.status_code == 200:
    print("Dữ liệu đã được gửi thành công đến n8n!")
else:
    print("Có lỗi xảy ra:", response.status_code)
    print(response.text)