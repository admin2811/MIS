import requests

url = "https://analyticsapi.zoho.com/restapi/v2/workspaces/2966205000000004005/views/2966205000000004015/data"

headers = {
    "ZANALYTICS-ORGID": "869591002",  
    "Authorization": "Zoho-oauthtoken 1000.7ca0589816f74235eb726a8f4260da7e.15eb29eb988b5bc18e97ffde8a115656"
}

params = {
    "CONFIG": '{"responseFormat":"json"}'
}

response = requests.get(url, headers=headers, params=params)

if response.status_code == 200:
    data = response.json()
    print("Dữ liệu nhận được:")
    print(data)
else:
    print(f"Yêu cầu thất bại với mã lỗi: {response.status_code}")
    print(response.text)